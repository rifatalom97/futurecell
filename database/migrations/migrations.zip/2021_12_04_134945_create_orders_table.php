<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->string('order_number');
            $table->integer('user_id');

            $table->string('currency_code',20);
            $table->string('currency_sign',20);
            
            $table->double('cart_total_amount')->default(0);
            $table->double('total_amount')->default(0);
            
            $table->text('coupon')->nullable();
            $table->text('delivery_option')->nullable();

            $table->string('shippingAddress_firstName',50);
            $table->string('shippingAddress_lastName',50);
            $table->string('shippingAddress_email',50);
            $table->string('shippingAddress_phone',50);
            $table->string('shippingAddress_company')->nullable();
            $table->string('shippingAddress_address');
            $table->string('shippingAddress_addressTwo')->nullable();
            $table->string('shippingAddress_city',50);
            $table->string('shippingAddress_state',50)->nullable();
            $table->integer('shippingAddress_country');
            $table->string('shippingAddress_zipCode',50);
            $table->text('shippingAddress_description')->nullable();

            $table->boolean('isBillsingAddress')->default(0);

            $table->string('billingAddress_name')->nullable();
            $table->string('billingAddress_email')->nullable();
            $table->string('billingAddress_phone')->nullable();
            $table->string('billingAddress_address')->nullable();
            $table->string('billingAddress_addressTwo')->nullable();
            $table->string('billingAddress_city')->nullable();
            $table->string('billingAddress_state')->nullable();
            $table->integer('billingAddress_country')->nullable();
            $table->string('billingAddress_zipCode')->nullable();

            $table->integer('transection_id')->nullable();
            $table->integer('return_transection_id')->nullable();
            $table->integer('point_transection_id')->nullable();
            $table->integer('wallet_transection_id')->nullable();

            $table->integer('canceled_by')->default(0);
            $table->dateTime('canceled_on')->default(0);
            
            $table->boolean('admin_view')->default(0);
            $table->integer('order_status')->default(0);
            $table->integer('paid')->default(0);

            $table->boolean('user_trashed')->default(false);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
